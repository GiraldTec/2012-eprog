package gui;

import javax.swing.SwingWorker;

import GACore.IGAEngine;

/***
 * 
 * Esta clase existe con fin de no bloquear la interfaz en previsi�n a problemas mucho m�s complejos 
 * en los que un step de la evoluci�n requiera un tiempo de procesamiento considerable
 *
 */

class GAStepThread extends SwingWorker<Void, Void> {
	@SuppressWarnings("rawtypes")
	IGAEngine gaEngine;
	double dataAbsoluteBest[];
	double dataGenerationBest[];
	double dataGenerationAverage[];
	double dataGenerationCount[];
	int progress;
	
	@SuppressWarnings("rawtypes")
	public GAStepThread (IGAEngine gaEngine, Object dataAbsoluteBest2, Object dataGenerationAverage2, Object dataGenerationBest2, Object dataGenerationCount2) {
		this.gaEngine = gaEngine;
		this.dataAbsoluteBest = (double[])dataAbsoluteBest2;
		this.dataGenerationAverage = (double[])dataGenerationBest2;
		this.dataGenerationBest = (double[])dataGenerationAverage2;
		this.dataGenerationCount = (double[])dataGenerationCount2;
	}
	
	// Main task. Executed in background thread.
    public Void doInBackground() {
    	int currGeneration = gaEngine.getCurrent_Generation();
    	progress = (currGeneration * 100) / gaEngine.getNum_Max_Gen();
        //Initialize progress property.
        setProgress(progress);
            while (!gaEngine.isEvol_Complete() && currGeneration < gaEngine.getNum_Max_Gen()){
            	try {
            		// ejecutamos un step de la evoluci�n
					gaEngine.runEvolutionStep();
				} catch (InstantiationException e) {
					e.printStackTrace();
				} catch (IllegalAccessException e) {
					e.printStackTrace();
				}		
				// actualizar resultados
				dataAbsoluteBest[currGeneration] = (Double)gaEngine.getAbsoluteBest();
				dataGenerationBest[currGeneration] = (Double)gaEngine.getGenerationBest();
				dataGenerationAverage[currGeneration] = gaEngine.getPopulation_Average();
				
				dataGenerationCount[currGeneration] = currGeneration;
				currGeneration = gaEngine.getCurrent_Generation();
				
				setProgress((currGeneration * 100) / gaEngine.getNum_Max_Gen());
			 }
			return null;
    }
}
